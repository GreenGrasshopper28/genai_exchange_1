
  # Travel App Development

  This is a code bundle for Travel App Development. The original project is available at https://www.figma.com/design/AgmoTHkRDxsO2pa9uJBFJ0/Travel-App-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  