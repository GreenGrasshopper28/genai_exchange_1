import React, { useState } from 'react';
import { User, Settings, Heart, MapPin, Plane, Star, Shield, LogOut, LogIn } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function UserProfile({ user, onSignIn, onSignOut }) {
  const [isEditing, setIsEditing] = useState(false);
  const [signInMode, setSignInMode] = useState('signin');
  const [authData, setAuthData] = useState({
    email: '',
    password: '',
    name: '',
    confirmPassword: ''
  });
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    bio: user?.bio || '',
    location: user?.location || '',
    interests: user?.interests || [],
    preferences: {
      budget: user?.preferences?.budget || 'moderate',
      travelStyle: user?.preferences?.travelStyle || 'cultural',
      notifications: user?.preferences?.notifications !== false
    }
  });

  const handleSignIn = async (e) => {
    e.preventDefault();
    
    if (signInMode === 'signup') {
      if (authData.password !== authData.confirmPassword) {
        toast.error('Passwords do not match');
        return;
      }
      if (!authData.name) {
        toast.error('Name is required for sign up');
        return;
      }
    }

    try {
      const endpoint = signInMode === 'signup' ? 'api/auth/signup' : 'api/auth/signin';
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(authData)
      });

      if (response.ok) {
        const userData = await response.json();
        onSignIn(userData);
        setAuthData({ email: '', password: '', name: '', confirmPassword: '' });
        toast.success(signInMode === 'signup' ? 'Account created successfully!' : 'Signed in successfully!');
      } else {
        const error = await response.text();
        throw new Error(error);
      }
    } catch (error) {
      console.error('Authentication error:', error);
      toast.error(error.message || 'Authentication failed');
    }
  };

  const handleSaveProfile = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/user/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          userId: user.id,
          ...profileData
        })
      });

      if (response.ok) {
        const updatedUser = await response.json();
        onSignIn(updatedUser);
        setIsEditing(false);
        toast.success('Profile updated successfully!');
      } else {
        throw new Error('Failed to update profile');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    }
  };

  const addInterest = (interest) => {
    if (interest && !profileData.interests.includes(interest)) {
      setProfileData(prev => ({
        ...prev,
        interests: [...prev.interests, interest]
      }));
    }
  };

  const removeInterest = (interest) => {
    setProfileData(prev => ({
      ...prev,
      interests: prev.interests.filter(i => i !== interest)
    }));
  };

  const suggestedInterests = [
    'Museums', 'Food & Dining', 'Adventure Sports', 'Beach', 'Mountains',
    'Cities', 'Photography', 'History', 'Art', 'Music', 'Shopping',
    'Nightlife', 'Nature', 'Architecture', 'Local Culture'
  ];

  if (!user) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-purple-600" />
              {signInMode === 'signup' ? 'Create Account' : 'Sign In'}
            </CardTitle>
            <CardDescription>
              {signInMode === 'signup' 
                ? 'Join TravelAI to save itineraries, track bookings, and get personalized recommendations'
                : 'Access your personalized travel dashboard and saved preferences'
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignIn} className="space-y-4">
              {signInMode === 'signup' && (
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter your full name"
                    value={authData.name}
                    onChange={(e) => setAuthData(prev => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>
              )}

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={authData.email}
                  onChange={(e) => setAuthData(prev => ({ ...prev, email: e.target.value }))}
                  required
                />
              </div>

              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={authData.password}
                  onChange={(e) => setAuthData(prev => ({ ...prev, password: e.target.value }))}
                  required
                />
              </div>

              {signInMode === 'signup' && (
                <div>
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your password"
                    value={authData.confirmPassword}
                    onChange={(e) => setAuthData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                    required
                  />
                </div>
              )}

              <Button type="submit" className="w-full">
                <LogIn className="mr-2 h-4 w-4" />
                {signInMode === 'signup' ? 'Create Account' : 'Sign In'}
              </Button>

              <div className="text-center">
                <Button
                  type="button"
                  variant="link"
                  onClick={() => setSignInMode(signInMode === 'signup' ? 'signin' : 'signup')}
                >
                  {signInMode === 'signup' 
                    ? 'Already have an account? Sign in'
                    : "Don't have an account? Sign up"
                  }
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Why Create an Account?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <Heart className="h-5 w-5 text-red-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Save Your Favorites</h4>
                <p className="text-sm text-gray-600">Keep track of places and experiences you love</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Plane className="h-5 w-5 text-blue-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Manage Bookings</h4>
                <p className="text-sm text-gray-600">Track all your travel bookings in one place</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Star className="h-5 w-5 text-yellow-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Personalized Recommendations</h4>
                <p className="text-sm text-gray-600">Get AI-powered suggestions based on your preferences</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white text-xl font-semibold">
                {user.name?.charAt(0)?.toUpperCase() || 'U'}
              </div>
              <div>
                <CardTitle className="text-2xl">{user.name}</CardTitle>
                <CardDescription>{user.email}</CardDescription>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setIsEditing(!isEditing)}
              >
                <Settings className="mr-2 h-4 w-4" />
                {isEditing ? 'Cancel' : 'Edit Profile'}
              </Button>
              <Button variant="outline" onClick={onSignOut}>
                <LogOut className="mr-2 h-4 w-4" />
                Sign Out
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Profile Information */}
        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEditing ? (
              <form className="space-y-4">
                <div>
                  <Label htmlFor="profileName">Name</Label>
                  <Input
                    id="profileName"
                    value={profileData.name}
                    onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    placeholder="e.g., New York, USA"
                    value={profileData.location}
                    onChange={(e) => setProfileData(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    placeholder="Tell us about yourself and your travel style..."
                    value={profileData.bio}
                    onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                    rows={3}
                  />
                </div>

                <Button onClick={handleSaveProfile} className="w-full">
                  Save Changes
                </Button>
              </form>
            ) : (
              <div className="space-y-3">
                <div>
                  <Label>Location</Label>
                  <p className="text-sm">{user.location || 'Not specified'}</p>
                </div>
                <div>
                  <Label>Bio</Label>
                  <p className="text-sm">{user.bio || 'No bio added yet'}</p>
                </div>
                <div>
                  <Label>Member Since</Label>
                  <p className="text-sm">{new Date(user.createdAt || Date.now()).toLocaleDateString()}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Travel Preferences */}
        <Card>
          <CardHeader>
            <CardTitle>Travel Preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isEditing ? (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="budget">Budget Preference</Label>
                  <Select 
                    value={profileData.preferences.budget} 
                    onValueChange={(value) => setProfileData(prev => ({
                      ...prev,
                      preferences: { ...prev.preferences, budget: value }
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="budget">Budget ($)</SelectItem>
                      <SelectItem value="moderate">Moderate ($$)</SelectItem>
                      <SelectItem value="luxury">Luxury ($$$)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="travelStyle">Travel Style</Label>
                  <Select 
                    value={profileData.preferences.travelStyle} 
                    onValueChange={(value) => setProfileData(prev => ({
                      ...prev,
                      preferences: { ...prev.preferences, travelStyle: value }
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cultural">Cultural Explorer</SelectItem>
                      <SelectItem value="adventure">Adventure Seeker</SelectItem>
                      <SelectItem value="relaxation">Relaxation Focused</SelectItem>
                      <SelectItem value="foodie">Food & Drink</SelectItem>
                      <SelectItem value="business">Business Travel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications">Push Notifications</Label>
                  <Switch
                    id="notifications"
                    checked={profileData.preferences.notifications}
                    onCheckedChange={(checked) => setProfileData(prev => ({
                      ...prev,
                      preferences: { ...prev.preferences, notifications: checked }
                    }))}
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <Label>Budget Preference</Label>
                  <p className="text-sm">{user.preferences?.budget || 'Moderate'}</p>
                </div>
                <div>
                  <Label>Travel Style</Label>
                  <p className="text-sm">{user.preferences?.travelStyle || 'Cultural Explorer'}</p>
                </div>
                <div>
                  <Label>Notifications</Label>
                  <p className="text-sm">{user.preferences?.notifications !== false ? 'Enabled' : 'Disabled'}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Travel Interests */}
      <Card>
        <CardHeader>
          <CardTitle>Travel Interests</CardTitle>
          <CardDescription>
            Help us personalize your travel recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isEditing ? (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {profileData.interests.map((interest) => (
                  <Badge key={interest} variant="default" className="cursor-pointer">
                    {interest}
                    <button
                      className="ml-2 text-xs"
                      onClick={() => removeInterest(interest)}
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>

              <Separator />

              <div>
                <Label>Add Interests</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {suggestedInterests
                    .filter(interest => !profileData.interests.includes(interest))
                    .map((interest) => (
                      <Badge
                        key={interest}
                        variant="outline"
                        className="cursor-pointer hover:bg-gray-100"
                        onClick={() => addInterest(interest)}
                      >
                        + {interest}
                      </Badge>
                    ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {(user.interests || []).length > 0 ? (
                user.interests.map((interest) => (
                  <Badge key={interest} variant="default">
                    {interest}
                  </Badge>
                ))
              ) : (
                <p className="text-sm text-gray-500">No interests added yet</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Account Security */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Account Security
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Password</h4>
                <p className="text-sm text-gray-600">Last updated: Recently</p>
              </div>
              <Button variant="outline" size="sm">
                Change Password
              </Button>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Two-Factor Authentication</h4>
                <p className="text-sm text-gray-600">Add an extra layer of security</p>
              </div>
              <Button variant="outline" size="sm">
                Enable 2FA
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}