import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, MapPin, DollarSign, Clock, Users, Plane, Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function AnalyticsDashboard({ user }) {
  const [timeRange, setTimeRange] = useState('6months');
  const [analyticsData, setAnalyticsData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadAnalyticsData();
    }
  }, [user, timeRange]);

  const loadAnalyticsData = async () => {
    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/analytics?userId=${user.id}&timeRange=${timeRange}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setAnalyticsData(data);
      }
    } catch (error) {
      console.error('Failed to load analytics data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Sample analytics data for demo
  const sampleData = {
    overview: {
      totalTrips: 12,
      totalSpent: 8450,
      totalDays: 89,
      averageTripLength: 7.4,
      favoriteDestination: 'Europe',
      savingsFromAI: 1250
    },
    travelTrends: [
      { month: 'Jan', trips: 2, spending: 1200 },
      { month: 'Feb', trips: 1, spending: 800 },
      { month: 'Mar', trips: 3, spending: 2100 },
      { month: 'Apr', trips: 2, spending: 1500 },
      { month: 'May', trips: 1, spending: 950 },
      { month: 'Jun', trips: 3, spending: 2200 }
    ],
    destinationBreakdown: [
      { name: 'Europe', value: 45, trips: 5, color: '#8884d8' },
      { name: 'Asia', value: 25, trips: 3, color: '#82ca9d' },
      { name: 'North America', value: 20, trips: 3, color: '#ffc658' },
      { name: 'South America', value: 10, trips: 1, color: '#ff7300' }
    ],
    budgetAnalysis: {
      totalBudget: 10000,
      spent: 8450,
      saved: 1550,
      categories: [
        { name: 'Flights', amount: 3200, percentage: 38 },
        { name: 'Hotels', amount: 2800, percentage: 33 },
        { name: 'Food', amount: 1500, percentage: 18 },
        { name: 'Activities', amount: 950, percentage: 11 }
      ]
    },
    preferences: {
      mostBookedCategory: 'Cultural Tours',
      averageStayLength: 4.2,
      preferredBudgetRange: 'Moderate',
      bookingLeadTime: '45 days'
    }
  };

  const displayData = analyticsData || sampleData;

  const StatCard = ({ title, value, subtitle, icon: Icon, trend, color = 'blue' }) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
          </div>
          <div className={`h-12 w-12 bg-${color}-100 rounded-full flex items-center justify-center`}>
            <Icon className={`h-6 w-6 text-${color}-600`} />
          </div>
        </div>
        {trend && (
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600">{trend}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (!user) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-indigo-600" />
              Analytics Dashboard
            </CardTitle>
            <CardDescription>
              Sign in to view your personalized travel analytics powered by BigQuery
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8 text-gray-500">
              <BarChart3 className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Sign in to access your travel analytics</p>
              <p className="text-sm">Track spending, discover patterns, and optimize your travel</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-indigo-600" />
                Analytics Dashboard
              </CardTitle>
              <CardDescription>
                Insights into your travel patterns, spending, and preferences powered by BigQuery
              </CardDescription>
            </div>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3months">Last 3 months</SelectItem>
                <SelectItem value="6months">Last 6 months</SelectItem>
                <SelectItem value="1year">Last year</SelectItem>
                <SelectItem value="all">All time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
      </Card>

      {/* Overview Stats */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Trips"
          value={displayData.overview.totalTrips}
          subtitle="Completed"
          icon={Plane}
          trend="+2 this month"
          color="blue"
        />
        <StatCard
          title="Total Spent"
          value={`$${displayData.overview.totalSpent.toLocaleString()}`}
          subtitle="All bookings"
          icon={DollarSign}
          trend="$320 avg/day"
          color="green"
        />
        <StatCard
          title="Travel Days"
          value={displayData.overview.totalDays}
          subtitle="Days traveled"
          icon={Calendar}
          trend={`${displayData.overview.averageTripLength} avg/trip`}
          color="purple"
        />
        <StatCard
          title="AI Savings"
          value={`$${displayData.overview.savingsFromAI}`}
          subtitle="Saved with AI recommendations"
          icon={TrendingUp}
          trend="15% total savings"
          color="orange"
        />
      </div>

      <Tabs defaultValue="trends" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="trends">Travel Trends</TabsTrigger>
          <TabsTrigger value="destinations">Destinations</TabsTrigger>
          <TabsTrigger value="budget">Budget Analysis</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
        </TabsList>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Travel Activity</CardTitle>
                <CardDescription>Number of trips per month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={displayData.travelTrends}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="trips" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Spending Over Time</CardTitle>
                <CardDescription>Monthly travel expenses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={displayData.travelTrends}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value}`, 'Spending']} />
                      <Line 
                        type="monotone" 
                        dataKey="spending" 
                        stroke="#82ca9d" 
                        strokeWidth={3}
                        dot={{ fill: '#82ca9d', strokeWidth: 2, r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="destinations" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Destination Breakdown</CardTitle>
                <CardDescription>Where you've traveled by region</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={displayData.destinationBreakdown}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {displayData.destinationBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Destinations</CardTitle>
                <CardDescription>Your most visited places</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {displayData.destinationBreakdown.map((destination, index) => (
                    <div key={destination.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: destination.color }}
                        />
                        <span className="font-medium">{destination.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{destination.trips} trips</Badge>
                          <span className="text-sm text-gray-600">{destination.value}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="budget" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Budget Overview</CardTitle>
                <CardDescription>Total budget vs actual spending</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Budget</span>
                    <span className="font-semibold">${displayData.budgetAnalysis.totalBudget.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Spent</span>
                    <span className="font-semibold text-blue-600">${displayData.budgetAnalysis.spent.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Remaining</span>
                    <span className="font-semibold text-green-600">${displayData.budgetAnalysis.saved.toLocaleString()}</span>
                  </div>
                  <Progress 
                    value={(displayData.budgetAnalysis.spent / displayData.budgetAnalysis.totalBudget) * 100} 
                    className="w-full"
                  />
                  <p className="text-sm text-gray-600 text-center">
                    {Math.round((displayData.budgetAnalysis.spent / displayData.budgetAnalysis.totalBudget) * 100)}% of budget used
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Spending by Category</CardTitle>
                <CardDescription>How you allocate your travel budget</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {displayData.budgetAnalysis.categories.map((category) => (
                    <div key={category.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{category.name}</span>
                        <span className="text-sm font-semibold">${category.amount.toLocaleString()}</span>
                      </div>
                      <Progress value={category.percentage} className="w-full" />
                      <p className="text-xs text-gray-600">{category.percentage}% of total spending</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Travel Preferences</CardTitle>
                <CardDescription>Your travel patterns and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Most Booked Category</span>
                    <Badge>{displayData.preferences.mostBookedCategory}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Average Stay Length</span>
                    <span className="font-medium">{displayData.preferences.averageStayLength} days</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Preferred Budget Range</span>
                    <Badge variant="outline">{displayData.preferences.preferredBudgetRange}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Booking Lead Time</span>
                    <span className="font-medium">{displayData.preferences.bookingLeadTime}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>AI Recommendations Impact</CardTitle>
                <CardDescription>How AI has improved your travel experience</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Money Saved</span>
                    <span className="font-semibold text-green-600">
                      ${displayData.overview.savingsFromAI.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Time Saved Planning</span>
                    <span className="font-medium">~24 hours</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Successful Recommendations</span>
                    <span className="font-medium">89%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Personalization Score</span>
                    <div className="flex items-center gap-2">
                      <Progress value={92} className="w-16" />
                      <span className="font-medium">92%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}