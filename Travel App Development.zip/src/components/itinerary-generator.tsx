import React, { useState, useEffect } from 'react';
import { Bot, MapPin, Clock, Users, Calendar, Share2, Download, Wand2, Loader2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function ItineraryGenerator({ user, onSignIn }) {
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [travelers, setTravelers] = useState('2');
  const [budget, setBudget] = useState('moderate');
  const [interests, setInterests] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [currentItinerary, setCurrentItinerary] = useState(null);
  const [savedItineraries, setSavedItineraries] = useState([]);

  useEffect(() => {
    if (user) {
      loadSavedItineraries();
    }
  }, [user]);

  const loadSavedItineraries = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/itineraries?userId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const itineraries = await response.json();
        setSavedItineraries(itineraries);
      }
    } catch (error) {
      console.error('Failed to load saved itineraries:', error);
    }
  };

  const generateItinerary = async () => {
    if (!destination || !startDate || !endDate) {
      toast.error('Please fill in destination and dates');
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);

    try {
      // Simulate AI generation progress
      const progressInterval = setInterval(() => {
        setGenerationProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/generate-itinerary`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          destination,
          startDate,
          endDate,
          travelers: parseInt(travelers),
          budget,
          interests,
          userId: user?.id
        })
      });

      clearInterval(progressInterval);
      setGenerationProgress(100);

      if (response.ok) {
        const itinerary = await response.json();
        setCurrentItinerary(itinerary);
        toast.success('Itinerary generated successfully!');
      } else {
        throw new Error('Failed to generate itinerary');
      }
    } catch (error) {
      console.error('Error generating itinerary:', error);
      toast.error('Failed to generate itinerary. Please try again.');
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
    }
  };

  const saveItinerary = async () => {
    if (!user) {
      toast.error('Please sign in to save itineraries');
      return;
    }

    if (!currentItinerary) {
      toast.error('No itinerary to save');
      return;
    }

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/itineraries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          ...currentItinerary,
          userId: user.id
        })
      });

      if (response.ok) {
        toast.success('Itinerary saved successfully!');
        loadSavedItineraries();
      } else {
        throw new Error('Failed to save itinerary');
      }
    } catch (error) {
      console.error('Error saving itinerary:', error);
      toast.error('Failed to save itinerary');
    }
  };

  const shareItinerary = () => {
    if (!currentItinerary) return;
    
    const shareUrl = `${window.location.origin}/shared-itinerary/${currentItinerary.id}`;
    navigator.clipboard.writeText(shareUrl);
    toast.success('Itinerary link copied to clipboard!');
  };

  const exportItinerary = () => {
    if (!currentItinerary) return;
    
    const dataStr = JSON.stringify(currentItinerary, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentItinerary.destination}-itinerary.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Itinerary exported successfully!');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-blue-600" />
            AI Itinerary Generator
          </CardTitle>
          <CardDescription>
            Let Gemini AI create the perfect travel itinerary based on your preferences, 
            with real-time data from Google Maps and personalized recommendations.
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Input Form */}
        <Card>
          <CardHeader>
            <CardTitle>Trip Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="destination">Destination</Label>
              <Input
                id="destination"
                placeholder="e.g., Paris, France"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate">Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="endDate">End Date</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="travelers">Travelers</Label>
                <Select value={travelers} onValueChange={setTravelers}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 person</SelectItem>
                    <SelectItem value="2">2 people</SelectItem>
                    <SelectItem value="3">3 people</SelectItem>
                    <SelectItem value="4">4 people</SelectItem>
                    <SelectItem value="5">5+ people</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="budget">Budget Level</Label>
                <Select value={budget} onValueChange={setBudget}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="budget">Budget ($)</SelectItem>
                    <SelectItem value="moderate">Moderate ($$)</SelectItem>
                    <SelectItem value="luxury">Luxury ($$$)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="interests">Interests & Preferences</Label>
              <Textarea
                id="interests"
                placeholder="e.g., museums, food tours, adventure activities, nightlife..."
                value={interests}
                onChange={(e) => setInterests(e.target.value)}
                rows={3}
              />
            </div>

            <Button 
              onClick={generateItinerary}
              disabled={isGenerating}
              className="w-full"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="mr-2 h-4 w-4" />
                  Generate Itinerary
                </>
              )}
            </Button>

            {isGenerating && (
              <div className="space-y-2">
                <Progress value={generationProgress} className="w-full" />
                <p className="text-sm text-gray-600 text-center">
                  {generationProgress < 30 && "Analyzing destination..."}
                  {generationProgress >= 30 && generationProgress < 60 && "Finding attractions..."}
                  {generationProgress >= 60 && generationProgress < 90 && "Optimizing routes..."}
                  {generationProgress >= 90 && "Finalizing itinerary..."}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Generated Itinerary */}
        <Card>
          <CardHeader>
            <CardTitle>Generated Itinerary</CardTitle>
            {currentItinerary && (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={saveItinerary}>
                  Save
                </Button>
                <Button variant="outline" size="sm" onClick={shareItinerary}>
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </Button>
                <Button variant="outline" size="sm" onClick={exportItinerary}>
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            )}
          </CardHeader>
          <CardContent>
            <AnimatePresence>
              {currentItinerary ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-4"
                >
                  <div>
                    <h3 className="font-semibold text-lg">{currentItinerary.title}</h3>
                    <p className="text-gray-600">{currentItinerary.destination}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500 mt-2">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {currentItinerary.duration} days
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {currentItinerary.travelers} travelers
                      </span>
                      <Badge variant="secondary">{currentItinerary.budget}</Badge>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    {currentItinerary.days?.map((day, index) => (
                      <div key={index} className="border-l-2 border-blue-200 pl-4">
                        <h4 className="font-medium">Day {day.day}</h4>
                        <p className="text-sm text-gray-600 mb-2">{day.theme}</p>
                        <div className="space-y-2">
                          {day.activities?.map((activity, actIndex) => (
                            <div key={actIndex} className="flex items-start gap-2 text-sm">
                              <Clock className="h-3 w-3 mt-1 text-gray-400" />
                              <div>
                                <span className="font-medium">{activity.time}</span>
                                <span className="mx-2">-</span>
                                <span>{activity.title}</span>
                                {activity.location && (
                                  <div className="flex items-center gap-1 text-gray-500">
                                    <MapPin className="h-3 w-3" />
                                    {activity.location}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  {currentItinerary.recommendations && (
                    <>
                      <Separator />
                      <div>
                        <h4 className="font-medium mb-2">AI Recommendations</h4>
                        <div className="flex flex-wrap gap-2">
                          {currentItinerary.recommendations.map((rec, index) => (
                            <Badge key={index} variant="outline">{rec}</Badge>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </motion.div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Bot className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>Generate an itinerary to see your personalized travel plan here</p>
                </div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </div>

      {/* Saved Itineraries */}
      {user && savedItineraries.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Your Saved Itineraries</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {savedItineraries.map((itinerary) => (
                <div
                  key={itinerary.id}
                  className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => setCurrentItinerary(itinerary)}
                >
                  <h4 className="font-medium">{itinerary.title}</h4>
                  <p className="text-sm text-gray-600">{itinerary.destination}</p>
                  <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                    <span>{itinerary.duration} days</span>
                    <span>•</span>
                    <span>{itinerary.travelers} travelers</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}