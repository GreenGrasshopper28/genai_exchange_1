import React, { useState, useEffect } from 'react';
import { Plane, Hotel, Car, MapPin, Calendar, Users, CreditCard, Star, Filter, Clock } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function BookingManager({ user }) {
  const [activeTab, setActiveTab] = useState('flights');
  const [searchResults, setSearchResults] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);
  
  // Flight search state
  const [flightSearch, setFlightSearch] = useState({
    from: '',
    to: '',
    departDate: '',
    returnDate: '',
    passengers: '1',
    class: 'economy'
  });

  // Hotel search state
  const [hotelSearch, setHotelSearch] = useState({
    destination: '',
    checkIn: '',
    checkOut: '',
    guests: '2',
    rooms: '1'
  });

  // Tour search state
  const [tourSearch, setTourSearch] = useState({
    destination: '',
    date: '',
    category: 'sightseeing',
    duration: 'half-day'
  });

  useEffect(() => {
    if (user) {
      loadBookings();
    }
  }, [user]);

  const loadBookings = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/bookings?userId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const bookingData = await response.json();
        setBookings(bookingData);
      }
    } catch (error) {
      console.error('Failed to load bookings:', error);
    }
  };

  const searchFlights = async () => {
    if (!flightSearch.from || !flightSearch.to || !flightSearch.departDate) {
      toast.error('Please fill in all required flight details');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/bookings/flights/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(flightSearch)
      });

      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.flights || []);
        toast.success(`Found ${data.flights?.length || 0} flights`);
      } else {
        throw new Error('Failed to search flights');
      }
    } catch (error) {
      console.error('Error searching flights:', error);
      toast.error('Failed to search flights. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const searchHotels = async () => {
    if (!hotelSearch.destination || !hotelSearch.checkIn || !hotelSearch.checkOut) {
      toast.error('Please fill in all required hotel details');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/bookings/hotels/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(hotelSearch)
      });

      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.hotels || []);
        toast.success(`Found ${data.hotels?.length || 0} hotels`);
      } else {
        throw new Error('Failed to search hotels');
      }
    } catch (error) {
      console.error('Error searching hotels:', error);
      toast.error('Failed to search hotels. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const searchTours = async () => {
    if (!tourSearch.destination || !tourSearch.date) {
      toast.error('Please fill in all required tour details');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/bookings/tours/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(tourSearch)
      });

      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.tours || []);
        toast.success(`Found ${data.tours?.length || 0} tours`);
      } else {
        throw new Error('Failed to search tours');
      }
    } catch (error) {
      console.error('Error searching tours:', error);
      toast.error('Failed to search tours. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const bookItem = async (item, type) => {
    if (!user) {
      toast.error('Please sign in to make bookings');
      return;
    }

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/bookings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          ...item,
          type,
          userId: user.id,
          bookingDate: new Date().toISOString(),
          status: 'pending'
        })
      });

      if (response.ok) {
        toast.success('Booking request submitted! Redirecting to payment...');
        loadBookings();
        // In a real app, this would redirect to payment processing
      } else {
        throw new Error('Failed to create booking');
      }
    } catch (error) {
      console.error('Error creating booking:', error);
      toast.error('Failed to create booking');
    }
  };

  const FlightSearchForm = () => (
    <Card>
      <CardHeader>
        <CardTitle>Search Flights</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="from">From</Label>
            <Input
              id="from"
              placeholder="e.g., New York (NYC)"
              value={flightSearch.from}
              onChange={(e) => setFlightSearch(prev => ({ ...prev, from: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="to">To</Label>
            <Input
              id="to"
              placeholder="e.g., Paris (CDG)"
              value={flightSearch.to}
              onChange={(e) => setFlightSearch(prev => ({ ...prev, to: e.target.value }))}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="departDate">Departure Date</Label>
            <Input
              id="departDate"
              type="date"
              value={flightSearch.departDate}
              onChange={(e) => setFlightSearch(prev => ({ ...prev, departDate: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="returnDate">Return Date (Optional)</Label>
            <Input
              id="returnDate"
              type="date"
              value={flightSearch.returnDate}
              onChange={(e) => setFlightSearch(prev => ({ ...prev, returnDate: e.target.value }))}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="passengers">Passengers</Label>
            <Select 
              value={flightSearch.passengers} 
              onValueChange={(value) => setFlightSearch(prev => ({ ...prev, passengers: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 Passenger</SelectItem>
                <SelectItem value="2">2 Passengers</SelectItem>
                <SelectItem value="3">3 Passengers</SelectItem>
                <SelectItem value="4">4+ Passengers</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="class">Class</Label>
            <Select 
              value={flightSearch.class} 
              onValueChange={(value) => setFlightSearch(prev => ({ ...prev, class: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="economy">Economy</SelectItem>
                <SelectItem value="premium">Premium Economy</SelectItem>
                <SelectItem value="business">Business</SelectItem>
                <SelectItem value="first">First Class</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={searchFlights} disabled={loading} className="w-full">
          <Plane className="mr-2 h-4 w-4" />
          Search Flights
        </Button>
      </CardContent>
    </Card>
  );

  const HotelSearchForm = () => (
    <Card>
      <CardHeader>
        <CardTitle>Search Hotels</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="destination">Destination</Label>
          <Input
            id="destination"
            placeholder="e.g., Paris, France"
            value={hotelSearch.destination}
            onChange={(e) => setHotelSearch(prev => ({ ...prev, destination: e.target.value }))}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="checkIn">Check-in Date</Label>
            <Input
              id="checkIn"
              type="date"
              value={hotelSearch.checkIn}
              onChange={(e) => setHotelSearch(prev => ({ ...prev, checkIn: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="checkOut">Check-out Date</Label>
            <Input
              id="checkOut"
              type="date"
              value={hotelSearch.checkOut}
              onChange={(e) => setHotelSearch(prev => ({ ...prev, checkOut: e.target.value }))}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="guests">Guests</Label>
            <Select 
              value={hotelSearch.guests} 
              onValueChange={(value) => setHotelSearch(prev => ({ ...prev, guests: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 Guest</SelectItem>
                <SelectItem value="2">2 Guests</SelectItem>
                <SelectItem value="3">3 Guests</SelectItem>
                <SelectItem value="4">4+ Guests</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="rooms">Rooms</Label>
            <Select 
              value={hotelSearch.rooms} 
              onValueChange={(value) => setHotelSearch(prev => ({ ...prev, rooms: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 Room</SelectItem>
                <SelectItem value="2">2 Rooms</SelectItem>
                <SelectItem value="3">3 Rooms</SelectItem>
                <SelectItem value="4">4+ Rooms</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={searchHotels} disabled={loading} className="w-full">
          <Hotel className="mr-2 h-4 w-4" />
          Search Hotels
        </Button>
      </CardContent>
    </Card>
  );

  const TourSearchForm = () => (
    <Card>
      <CardHeader>
        <CardTitle>Search Tours & Activities</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="tourDestination">Destination</Label>
          <Input
            id="tourDestination"
            placeholder="e.g., Rome, Italy"
            value={tourSearch.destination}
            onChange={(e) => setTourSearch(prev => ({ ...prev, destination: e.target.value }))}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="tourDate">Date</Label>
            <Input
              id="tourDate"
              type="date"
              value={tourSearch.date}
              onChange={(e) => setTourSearch(prev => ({ ...prev, date: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="duration">Duration</Label>
            <Select 
              value={tourSearch.duration} 
              onValueChange={(value) => setTourSearch(prev => ({ ...prev, duration: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="half-day">Half Day (4 hours)</SelectItem>
                <SelectItem value="full-day">Full Day (8 hours)</SelectItem>
                <SelectItem value="multi-day">Multi Day</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="category">Category</Label>
          <Select 
            value={tourSearch.category} 
            onValueChange={(value) => setTourSearch(prev => ({ ...prev, category: value }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sightseeing">Sightseeing</SelectItem>
              <SelectItem value="food">Food & Drink</SelectItem>
              <SelectItem value="adventure">Adventure</SelectItem>
              <SelectItem value="cultural">Cultural</SelectItem>
              <SelectItem value="museums">Museums</SelectItem>
              <SelectItem value="outdoor">Outdoor Activities</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button onClick={searchTours} disabled={loading} className="w-full">
          <MapPin className="mr-2 h-4 w-4" />
          Search Tours
        </Button>
      </CardContent>
    </Card>
  );

  const SearchResults = () => (
    <Card>
      <CardHeader>
        <CardTitle>Search Results</CardTitle>
        <CardDescription>
          {searchResults.length > 0 ? `Found ${searchResults.length} results` : 'No results to display'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {searchResults.length > 0 ? (
          <div className="space-y-4">
            {searchResults.map((item, index) => (
              <Card key={index} className="border">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium">{item.name || item.airline}</h3>
                      <p className="text-sm text-gray-600">{item.description || item.route}</p>
                      
                      {item.rating && (
                        <div className="flex items-center gap-1 mt-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="text-sm">{item.rating}</span>
                        </div>
                      )}

                      {item.duration && (
                        <div className="flex items-center gap-1 mt-1">
                          <Clock className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">{item.duration}</span>
                        </div>
                      )}

                      {item.amenities && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {item.amenities.slice(0, 3).map((amenity, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {amenity}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="text-right">
                      <div className="text-lg font-semibold">${item.price}</div>
                      {item.originalPrice && item.originalPrice > item.price && (
                        <div className="text-sm text-gray-500 line-through">
                          ${item.originalPrice}
                        </div>
                      )}
                      <Button 
                        size="sm" 
                        className="mt-2"
                        onClick={() => bookItem(item, activeTab)}
                      >
                        Book Now
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <div className="h-12 w-12 mx-auto mb-4 text-gray-300">
              {activeTab === 'flights' && <Plane className="h-full w-full" />}
              {activeTab === 'hotels' && <Hotel className="h-full w-full" />}
              {activeTab === 'tours' && <MapPin className="h-full w-full" />}
            </div>
            <p>No search results yet</p>
            <p className="text-sm">Use the search form to find available options</p>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plane className="h-5 w-5 text-blue-600" />
            Booking Manager
          </CardTitle>
          <CardDescription>
            Search and book flights, hotels, and tours with integrated payment processing
            and real-time availability from multiple providers.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="flights" className="flex items-center gap-2">
            <Plane className="h-4 w-4" />
            Flights
          </TabsTrigger>
          <TabsTrigger value="hotels" className="flex items-center gap-2">
            <Hotel className="h-4 w-4" />
            Hotels
          </TabsTrigger>
          <TabsTrigger value="tours" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Tours
          </TabsTrigger>
          <TabsTrigger value="bookings" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            My Bookings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="flights" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <FlightSearchForm />
            <SearchResults />
          </div>
        </TabsContent>

        <TabsContent value="hotels" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <HotelSearchForm />
            <SearchResults />
          </div>
        </TabsContent>

        <TabsContent value="tours" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <TourSearchForm />
            <SearchResults />
          </div>
        </TabsContent>

        <TabsContent value="bookings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Bookings</CardTitle>
              <CardDescription>
                {user ? `You have ${bookings.length} bookings` : 'Sign in to view your bookings'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {user ? (
                bookings.length > 0 ? (
                  <div className="space-y-4">
                    {bookings.map((booking) => (
                      <Card key={booking.id} className="border">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-medium">{booking.name}</h3>
                              <p className="text-sm text-gray-600">{booking.type}</p>
                              <div className="flex items-center gap-4 text-sm text-gray-500 mt-2">
                                <span>Booking Date: {new Date(booking.bookingDate).toLocaleDateString()}</span>
                                <Badge variant={booking.status === 'confirmed' ? 'default' : 'secondary'}>
                                  {booking.status}
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-semibold">${booking.price}</div>
                              <Button variant="outline" size="sm" className="mt-2">
                                View Details
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No bookings yet</p>
                    <p className="text-sm">Start booking your dream trip!</p>
                  </div>
                )
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>Sign in to view your bookings</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}