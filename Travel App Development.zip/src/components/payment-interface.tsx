import React, { useState, useEffect } from 'react';
import { CreditCard, Smartphone, Shield, CheckCircle, AlertCircle, Plus, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function PaymentInterface({ user }) {
  const [activeTab, setActiveTab] = useState('methods');
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [newCard, setNewCard] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: '',
    type: ''
  });
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [googlePayEnabled, setGooglePayEnabled] = useState(false);

  useEffect(() => {
    if (user) {
      loadPaymentMethods();
      loadTransactions();
      checkGooglePayStatus();
    }
  }, [user]);

  const loadPaymentMethods = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/payments/methods?userId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const methods = await response.json();
        setPaymentMethods(methods);
      }
    } catch (error) {
      console.error('Failed to load payment methods:', error);
    }
  };

  const loadTransactions = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/payments/transactions?userId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const transactionData = await response.json();
        setTransactions(transactionData);
      }
    } catch (error) {
      console.error('Failed to load transactions:', error);
    }
  };

  const checkGooglePayStatus = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/payments/google-pay/status?userId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const status = await response.json();
        setGooglePayEnabled(status.enabled);
      }
    } catch (error) {
      console.error('Failed to check Google Pay status:', error);
    }
  };

  const addPaymentMethod = async (e) => {
    e.preventDefault();
    
    // Basic validation
    if (!newCard.number || !newCard.expiry || !newCard.cvv || !newCard.name) {
      toast.error('Please fill in all card details');
      return;
    }

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/payments/methods`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          userId: user.id,
          ...newCard,
          // In production, this would be tokenized by a payment processor
          lastFour: newCard.number.slice(-4),
          brand: detectCardBrand(newCard.number)
        })
      });

      if (response.ok) {
        await loadPaymentMethods();
        setNewCard({ number: '', expiry: '', cvv: '', name: '', type: '' });
        setIsAddingCard(false);
        toast.success('Payment method added successfully');
      } else {
        throw new Error('Failed to add payment method');
      }
    } catch (error) {
      console.error('Error adding payment method:', error);
      toast.error('Failed to add payment method');
    }
  };

  const removePaymentMethod = async (methodId) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/payments/methods/${methodId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ userId: user.id })
      });

      if (response.ok) {
        await loadPaymentMethods();
        toast.success('Payment method removed');
      } else {
        throw new Error('Failed to remove payment method');
      }
    } catch (error) {
      console.error('Error removing payment method:', error);
      toast.error('Failed to remove payment method');
    }
  };

  const enableGooglePay = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/payments/google-pay/enable`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ userId: user.id })
      });

      if (response.ok) {
        setGooglePayEnabled(true);
        toast.success('Google Pay enabled successfully');
      } else {
        throw new Error('Failed to enable Google Pay');
      }
    } catch (error) {
      console.error('Error enabling Google Pay:', error);
      toast.error('Failed to enable Google Pay');
    }
  };

  const detectCardBrand = (number) => {
    const num = number.replace(/\s/g, '');
    if (num.startsWith('4')) return 'Visa';
    if (num.startsWith('5') || num.startsWith('2')) return 'Mastercard';
    if (num.startsWith('3')) return 'American Express';
    return 'Unknown';
  };

  const formatCardNumber = (value) => {
    const num = value.replace(/\s/g, '').replace(/[^0-9]/gi, '');
    const matches = num.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return match;
    }
  };

  // Sample data for demo
  const sampleMethods = [
    {
      id: '1',
      brand: 'Visa',
      lastFour: '4242',
      expiry: '12/25',
      name: 'John Doe',
      isDefault: true
    },
    {
      id: '2',
      brand: 'Mastercard',
      lastFour: '5555',
      expiry: '08/26',
      name: 'John Doe',
      isDefault: false
    }
  ];

  const sampleTransactions = [
    {
      id: '1',
      type: 'flight',
      description: 'Flight NYC to Paris',
      amount: 850,
      date: '2024-01-15',
      status: 'completed',
      method: 'Visa •••• 4242'
    },
    {
      id: '2',
      type: 'hotel',
      description: 'Hotel Booking - Paris',
      amount: 450,
      date: '2024-01-12',
      status: 'completed',
      method: 'Google Pay'
    },
    {
      id: '3',
      type: 'tour',
      description: 'Seine River Cruise',
      amount: 75,
      date: '2024-01-10',
      status: 'pending',
      method: 'Mastercard •••• 5555'
    }
  ];

  const displayMethods = paymentMethods.length > 0 ? paymentMethods : sampleMethods;
  const displayTransactions = transactions.length > 0 ? transactions : sampleTransactions;

  if (!user) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-green-600" />
              Payment Interface
            </CardTitle>
            <CardDescription>
              Sign in to manage payment methods and view transaction history
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8 text-gray-500">
              <CreditCard className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Sign in to access payment features</p>
              <p className="text-sm">Secure payments powered by Google Pay</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-green-600" />
            Payment Interface
          </CardTitle>
          <CardDescription>
            Manage your payment methods and view transaction history. 
            Powered by Google Pay for secure, fast payments.
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Payment Methods */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Payment Methods</CardTitle>
                <Button 
                  size="sm" 
                  onClick={() => setIsAddingCard(true)}
                  disabled={isAddingCard}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Card
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isAddingCard && (
                <Card className="mb-6 border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg">Add New Card</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={addPaymentMethod} className="space-y-4">
                      <div>
                        <Label htmlFor="cardNumber">Card Number</Label>
                        <Input
                          id="cardNumber"
                          placeholder="1234 5678 9012 3456"
                          value={newCard.number}
                          onChange={(e) => setNewCard(prev => ({ 
                            ...prev, 
                            number: formatCardNumber(e.target.value) 
                          }))}
                          maxLength={19}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="expiry">Expiry Date</Label>
                          <Input
                            id="expiry"
                            placeholder="MM/YY"
                            value={newCard.expiry}
                            onChange={(e) => {
                              let value = e.target.value.replace(/\D/g, '');
                              if (value.length >= 2) {
                                value = value.substring(0, 2) + '/' + value.substring(2, 4);
                              }
                              setNewCard(prev => ({ ...prev, expiry: value }));
                            }}
                            maxLength={5}
                          />
                        </div>
                        <div>
                          <Label htmlFor="cvv">CVV</Label>
                          <Input
                            id="cvv"
                            placeholder="123"
                            value={newCard.cvv}
                            onChange={(e) => setNewCard(prev => ({ 
                              ...prev, 
                              cvv: e.target.value.replace(/\D/g, '') 
                            }))}
                            maxLength={4}
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="cardName">Cardholder Name</Label>
                        <Input
                          id="cardName"
                          placeholder="John Doe"
                          value={newCard.name}
                          onChange={(e) => setNewCard(prev => ({ ...prev, name: e.target.value }))}
                        />
                      </div>

                      <div className="flex gap-2">
                        <Button type="submit">Add Card</Button>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => {
                            setIsAddingCard(false);
                            setNewCard({ number: '', expiry: '', cvv: '', name: '', type: '' });
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              )}

              <div className="space-y-3">
                {displayMethods.map((method) => (
                  <Card key={method.id} className="border">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-16 bg-gray-100 rounded flex items-center justify-center">
                            <CreditCard className="h-5 w-5 text-gray-600" />
                          </div>
                          <div>
                            <p className="font-medium">
                              {method.brand} •••• {method.lastFour}
                            </p>
                            <p className="text-sm text-gray-600">
                              Expires {method.expiry} • {method.name}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {method.isDefault && (
                            <Badge variant="default">Default</Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removePaymentMethod(method.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Transaction History */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {displayTransactions.map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                        {transaction.type === 'flight' && <CreditCard className="h-5 w-5 text-blue-600" />}
                        {transaction.type === 'hotel' && <CreditCard className="h-5 w-5 text-green-600" />}
                        {transaction.type === 'tour' && <CreditCard className="h-5 w-5 text-purple-600" />}
                      </div>
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <p className="text-sm text-gray-600">
                          {new Date(transaction.date).toLocaleDateString()} • {transaction.method}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">${transaction.amount}</p>
                      <Badge 
                        variant={transaction.status === 'completed' ? 'default' : 'secondary'}
                        className="mt-1"
                      >
                        {transaction.status === 'completed' && <CheckCircle className="mr-1 h-3 w-3" />}
                        {transaction.status === 'pending' && <AlertCircle className="mr-1 h-3 w-3" />}
                        {transaction.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Google Pay */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="h-5 w-5 text-blue-600" />
                Google Pay
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Enable Google Pay</span>
                  <Switch
                    checked={googlePayEnabled}
                    onCheckedChange={(checked) => {
                      if (checked && !googlePayEnabled) {
                        enableGooglePay();
                      }
                    }}
                  />
                </div>
                
                {googlePayEnabled ? (
                  <div className="text-center py-4">
                    <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                    <p className="text-sm text-green-600">Google Pay is enabled</p>
                    <p className="text-xs text-gray-600">Fast, secure payments ready</p>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-sm text-gray-600">Enable for faster checkout</p>
                    <Button 
                      size="sm" 
                      className="mt-2"
                      onClick={enableGooglePay}
                    >
                      Set up Google Pay
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Security */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-600" />
                Security
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">256-bit SSL encryption</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">PCI DSS compliant</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Fraud protection</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Secure tokenization</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Total Spent</span>
                  <span className="font-semibold">$1,375</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>This Month</span>
                  <span className="font-semibold">$850</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Saved with AI</span>
                  <span className="font-semibold text-green-600">$125</span>
                </div>
                <Separator />
                <div className="flex items-center justify-between text-sm">
                  <span>Payment Methods</span>
                  <Badge variant="outline">{displayMethods.length}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}