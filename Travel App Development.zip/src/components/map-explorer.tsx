import React, { useState, useEffect } from 'react';
import { MapPin, Search, Navigation, Star, Clock, Phone, Globe, Heart, Camera } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner@2.0.3';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function MapExplorer({ user }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [mapData, setMapData] = useState(null);
  const [nearbyPlaces, setNearbyPlaces] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('tourist_attraction');
  const [userLocation, setUserLocation] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getUserLocation();
    if (user) {
      loadFavorites();
    }
  }, [user]);

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting user location:', error.message || 'Location access denied');
          // Set a default location (e.g., New York) if geolocation fails
          setUserLocation({
            lat: 40.7128,
            lng: -74.0060
          });
        },
        {
          enableHighAccuracy: false,
          timeout: 10000,
          maximumAge: 300000
        }
      );
    } else {
      console.warn('Geolocation is not supported by this browser');
      // Set a default location
      setUserLocation({
        lat: 40.7128,
        lng: -74.0060
      });
    }
  };

  const loadFavorites = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/favorites?userId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const favoritesData = await response.json();
        setFavorites(favoritesData);
      }
    } catch (error) {
      console.error('Failed to load favorites:', error);
    }
  };

  const searchLocation = async () => {
    if (!searchQuery.trim()) {
      toast.error('Please enter a location to search');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/maps/search?query=${encodeURIComponent(searchQuery)}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setMapData(data);
        setSelectedLocation(searchQuery);
        await searchNearbyPlaces(data.location, selectedCategory);
      } else {
        throw new Error('Failed to search location');
      }
    } catch (error) {
      console.error('Error searching location:', error);
      toast.error('Failed to search location. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const searchNearbyPlaces = async (location, category) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/maps/nearby?lat=${location.lat}&lng=${location.lng}&type=${category}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setNearbyPlaces(data.places || []);
      }
    } catch (error) {
      console.error('Error searching nearby places:', error);
    }
  };

  const getDirections = async (destination) => {
    if (!userLocation) {
      toast.error('Location access required for directions');
      return;
    }

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/maps/directions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          origin: userLocation,
          destination: destination.location,
          mode: 'driving'
        })
      });

      if (response.ok) {
        const directionsData = await response.json();
        toast.success(`Route found: ${directionsData.duration} (${directionsData.distance})`);
      }
    } catch (error) {
      console.error('Error getting directions:', error);
      toast.error('Failed to get directions');
    }
  };

  const toggleFavorite = async (place) => {
    if (!user) {
      toast.error('Please sign in to save favorites');
      return;
    }

    const isFavorite = favorites.some(fav => fav.placeId === place.placeId);
    
    try {
      if (isFavorite) {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/favorites/${place.placeId}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({ userId: user.id })
        });
        
        if (response.ok) {
          setFavorites(favorites.filter(fav => fav.placeId !== place.placeId));
          toast.success('Removed from favorites');
        }
      } else {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/favorites`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            ...place,
            userId: user.id
          })
        });
        
        if (response.ok) {
          setFavorites([...favorites, place]);
          toast.success('Added to favorites');
        }
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
      toast.error('Failed to update favorites');
    }
  };

  const categoryOptions = [
    { value: 'tourist_attraction', label: 'Tourist Attractions' },
    { value: 'restaurant', label: 'Restaurants' },
    { value: 'lodging', label: 'Hotels' },
    { value: 'museum', label: 'Museums' },
    { value: 'park', label: 'Parks' },
    { value: 'shopping_mall', label: 'Shopping' },
    { value: 'night_club', label: 'Nightlife' },
    { value: 'hospital', label: 'Healthcare' },
    { value: 'bank', label: 'Banks & ATMs' },
    { value: 'gas_station', label: 'Gas Stations' }
  ];

  const PlaceCard = ({ place }) => {
    const isFavorite = favorites.some(fav => fav.placeId === place.placeId);
    
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <h3 className="font-medium">{place.name}</h3>
              <p className="text-sm text-gray-600">{place.vicinity}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleFavorite(place)}
              className={isFavorite ? 'text-red-500' : 'text-gray-400'}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
            </Button>
          </div>

          {place.photos && place.photos.length > 0 && (
            <div className="mb-3">
              <ImageWithFallback
                src={place.photos[0]}
                alt={place.name}
                className="w-full h-32 object-cover rounded"
              />
            </div>
          )}

          <div className="space-y-2">
            {place.rating && (
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500 fill-current" />
                <span className="text-sm">{place.rating}</span>
                {place.userRatingsTotal && (
                  <span className="text-xs text-gray-500">({place.userRatingsTotal} reviews)</span>
                )}
              </div>
            )}

            {place.priceLevel && (
              <Badge variant="outline">
                {'$'.repeat(place.priceLevel)}
              </Badge>
            )}

            {place.openingHours && (
              <div className="flex items-center gap-1 text-sm">
                <Clock className="h-3 w-3 text-gray-400" />
                <span className={place.openingHours.openNow ? 'text-green-600' : 'text-red-600'}>
                  {place.openingHours.openNow ? 'Open now' : 'Closed'}
                </span>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => getDirections(place)}
              >
                <Navigation className="mr-1 h-3 w-3" />
                Directions
              </Button>
              
              {place.website && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(place.website, '_blank')}
                >
                  <Globe className="mr-1 h-3 w-3" />
                  Website
                </Button>
              )}
              
              {place.phoneNumber && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(`tel:${place.phoneNumber}`, '_blank')}
                >
                  <Phone className="mr-1 h-3 w-3" />
                  Call
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-green-600" />
            Map Explorer
          </CardTitle>
          <CardDescription>
            Discover places around the world with Google Maps integration, 
            real-time information, and personalized recommendations.
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Search Controls */}
      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Search for a city, landmark, or address..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && searchLocation()}
                className="flex-1"
              />
              <Button onClick={searchLocation} disabled={loading}>
                <Search className="mr-2 h-4 w-4" />
                Search
              </Button>
            </div>

            <div className="flex gap-4">
              <div className="flex-1">
                <label className="text-sm font-medium mb-2 block">Category</label>
                <Select 
                  value={selectedCategory} 
                  onValueChange={(value) => {
                    setSelectedCategory(value);
                    if (mapData?.location) {
                      searchNearbyPlaces(mapData.location, value);
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categoryOptions.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="explore" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="explore">Explore</TabsTrigger>
          <TabsTrigger value="favorites">Favorites</TabsTrigger>
          <TabsTrigger value="photos">Photo Gallery</TabsTrigger>
        </TabsList>

        <TabsContent value="explore" className="space-y-6">
          {/* Map Placeholder */}
          {selectedLocation && (
            <Card>
              <CardHeader>
                <CardTitle>Map View - {selectedLocation}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                  <div className="text-center text-gray-500">
                    <MapPin className="h-12 w-12 mx-auto mb-2" />
                    <p>Interactive Google Maps integration</p>
                    <p className="text-sm">Map view would appear here in production</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Nearby Places */}
          {nearbyPlaces.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>
                  Nearby {categoryOptions.find(cat => cat.value === selectedCategory)?.label}
                </CardTitle>
                <CardDescription>
                  Found {nearbyPlaces.length} places near {selectedLocation}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {nearbyPlaces.map((place, index) => (
                    <PlaceCard key={place.placeId || index} place={place} />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="favorites" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Favorite Places</CardTitle>
              <CardDescription>
                {user ? `You have ${favorites.length} saved places` : 'Sign in to save your favorite places'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {user ? (
                favorites.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {favorites.map((place) => (
                      <PlaceCard key={place.placeId} place={place} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Heart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No favorite places yet</p>
                    <p className="text-sm">Start exploring and save places you love!</p>
                  </div>
                )
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Heart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>Sign in to save your favorite places</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="photos" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Photo Gallery
              </CardTitle>
              <CardDescription>
                Explore beautiful photos from around the world
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <Camera className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>Photo gallery feature</p>
                <p className="text-sm">Integration with Google Places photos would appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}