import React, { useState, useEffect } from 'react';
import { Bell, Plane, Hotel, MapPin, CreditCard, Check, X, Clock, Settings } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function NotificationCenter({ notifications, onNotificationUpdate, user }) {
  const [notificationSettings, setNotificationSettings] = useState({
    bookingUpdates: true,
    priceAlerts: true,
    itineraryReminders: true,
    promotions: false,
    weatherAlerts: true
  });

  useEffect(() => {
    if (user) {
      loadNotificationSettings();
    }
  }, [user]);

  const loadNotificationSettings = async () => {
    if (!user?.id) return;
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/notifications/settings?userId=${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      if (response.ok) {
        const settings = await response.json();
        setNotificationSettings(settings);
      }
    } catch (error) {
      console.error('Failed to load notification settings:', error);
    }
  };

  const updateNotificationSettings = async (newSettings) => {
    if (!user?.id) {
      toast.error('Please sign in to update notification settings');
      return;
    }
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/notifications/settings`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          userId: user.id,
          ...newSettings
        })
      });

      if (response.ok) {
        setNotificationSettings(newSettings);
        toast.success('Notification settings updated');
      }
    } catch (error) {
      console.error('Failed to update notification settings:', error);
      toast.error('Failed to update settings');
    }
  };

  const markAsRead = async (notificationId) => {
    if (!user?.id) {
      toast.error('Please sign in to manage notifications');
      return;
    }
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/notifications/${notificationId}/read`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ userId: user.id })
      });

      if (response.ok) {
        const updatedNotifications = notifications.map(notif =>
          notif.id === notificationId ? { ...notif, read: true } : notif
        );
        onNotificationUpdate(updatedNotifications);
      }
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    if (!user?.id) {
      toast.error('Please sign in to manage notifications');
      return;
    }
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/notifications/mark-all-read`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ userId: user.id })
      });

      if (response.ok) {
        const updatedNotifications = notifications.map(notif => ({ ...notif, read: true }));
        onNotificationUpdate(updatedNotifications);
        toast.success('All notifications marked as read');
      }
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
      toast.error('Failed to update notifications');
    }
  };

  const deleteNotification = async (notificationId) => {
    if (!user?.id) {
      toast.error('Please sign in to manage notifications');
      return;
    }
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-04578462/api/notifications/${notificationId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ userId: user.id })
      });

      if (response.ok) {
        const updatedNotifications = notifications.filter(notif => notif.id !== notificationId);
        onNotificationUpdate(updatedNotifications);
        toast.success('Notification deleted');
      }
    } catch (error) {
      console.error('Failed to delete notification:', error);
      toast.error('Failed to delete notification');
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'booking':
        return <Plane className="h-4 w-4 text-blue-500" />;
      case 'hotel':
        return <Hotel className="h-4 w-4 text-green-500" />;
      case 'tour':
        return <MapPin className="h-4 w-4 text-purple-500" />;
      case 'payment':
        return <CreditCard className="h-4 w-4 text-orange-500" />;
      case 'reminder':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <Bell className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatNotificationTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now - date) / (1000 * 60));

    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  // Sample notifications for demo
  const sampleNotifications = [
    {
      id: '1',
      type: 'booking',
      title: 'Flight Booking Confirmed',
      message: 'Your flight from NYC to Paris has been confirmed. Check-in opens 24 hours before departure.',
      timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      read: false,
      actionUrl: '/bookings/flight-123'
    },
    {
      id: '2',
      type: 'reminder',
      title: 'Trip Reminder',
      message: 'Your Paris trip starts in 3 days! Don\'t forget to check the weather and pack accordingly.',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      read: false
    },
    {
      id: '3',
      type: 'hotel',
      title: 'Hotel Price Drop',
      message: 'Great news! The price for your saved hotel in Paris has dropped by $50/night.',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      read: true
    },
    {
      id: '4',
      type: 'tour',
      title: 'New Tour Available',
      message: 'A new food tour has been added to your Paris itinerary based on your preferences.',
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
      read: true
    }
  ];

  const displayNotifications = notifications.length > 0 ? notifications : sampleNotifications;
  const unreadCount = displayNotifications.filter(notif => !notif.read).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-orange-600" />
                Notification Center
                {unreadCount > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {unreadCount} new
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Stay updated on your bookings, itineraries, and travel alerts powered by Firebase
              </CardDescription>
            </div>
            {unreadCount > 0 && (
              <Button variant="outline" onClick={markAllAsRead}>
                <Check className="mr-2 h-4 w-4" />
                Mark All Read
              </Button>
            )}
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Notifications List */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              {displayNotifications.length > 0 ? (
                <div className="space-y-4">
                  {displayNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border rounded-lg transition-colors ${
                        notification.read ? 'bg-gray-50' : 'bg-blue-50 border-blue-200'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          {getNotificationIcon(notification.type)}
                          <div className="flex-1">
                            <h4 className={`font-medium ${!notification.read ? 'text-blue-900' : ''}`}>
                              {notification.title}
                            </h4>
                            <p className="text-sm text-gray-600 mt-1">
                              {notification.message}
                            </p>
                            <p className="text-xs text-gray-500 mt-2">
                              {formatNotificationTime(notification.timestamp)}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-1 ml-2">
                          {!notification.read && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => markAsRead(notification.id)}
                              className="h-8 w-8 p-0"
                            >
                              <Check className="h-3 w-3" />
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteNotification(notification.id)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      {notification.actionUrl && (
                        <div className="mt-3">
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Bell className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No notifications yet</p>
                  <p className="text-sm">You'll see travel updates and alerts here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Notification Settings */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Notification Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {user ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="bookingUpdates" className="text-sm">
                      Booking Updates
                    </Label>
                    <Switch
                      id="bookingUpdates"
                      checked={notificationSettings.bookingUpdates}
                      onCheckedChange={(checked) => 
                        updateNotificationSettings({ ...notificationSettings, bookingUpdates: checked })
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="priceAlerts" className="text-sm">
                      Price Alerts
                    </Label>
                    <Switch
                      id="priceAlerts"
                      checked={notificationSettings.priceAlerts}
                      onCheckedChange={(checked) => 
                        updateNotificationSettings({ ...notificationSettings, priceAlerts: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="itineraryReminders" className="text-sm">
                      Itinerary Reminders
                    </Label>
                    <Switch
                      id="itineraryReminders"
                      checked={notificationSettings.itineraryReminders}
                      onCheckedChange={(checked) => 
                        updateNotificationSettings({ ...notificationSettings, itineraryReminders: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="weatherAlerts" className="text-sm">
                      Weather Alerts
                    </Label>
                    <Switch
                      id="weatherAlerts"
                      checked={notificationSettings.weatherAlerts}
                      onCheckedChange={(checked) => 
                        updateNotificationSettings({ ...notificationSettings, weatherAlerts: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <Label htmlFor="promotions" className="text-sm">
                      Promotions & Offers
                    </Label>
                    <Switch
                      id="promotions"
                      checked={notificationSettings.promotions}
                      onCheckedChange={(checked) => 
                        updateNotificationSettings({ ...notificationSettings, promotions: checked })
                      }
                    />
                  </div>
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500">
                  <p className="text-sm">Sign in to customize notification settings</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle>Notification Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Total Notifications</span>
                  <Badge variant="outline">{displayNotifications.length}</Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Unread</span>
                  <Badge variant={unreadCount > 0 ? 'destructive' : 'outline'}>
                    {unreadCount}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>This Week</span>
                  <Badge variant="outline">
                    {displayNotifications.filter(n => 
                      new Date(n.timestamp) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
                    ).length}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}