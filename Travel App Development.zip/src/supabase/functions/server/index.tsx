import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createClient } from "jsr:@supabase/supabase-js@2";

const app = new Hono();

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-04578462/health", (c) => {
  return c.json({ status: "ok" });
});

// ==================== AUTH ROUTES ====================

// Sign up
app.post("/make-server-04578462/api/auth/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.error('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Store user data in KV store
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email: data.user.email,
      name,
      createdAt: new Date().toISOString(),
      preferences: {
        budget: 'moderate',
        travelStyle: 'cultural',
        notifications: true
      },
      interests: []
    });

    return c.json({
      id: data.user.id,
      email: data.user.email,
      name
    });
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Failed to create account' }, 500);
  }
});

// Sign in
app.post("/make-server-04578462/api/auth/signin", async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      console.error('Signin error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Get user data from KV store
    const userData = await kv.get(`user:${data.user.id}`);
    
    return c.json(userData || {
      id: data.user.id,
      email: data.user.email,
      name: data.user.user_metadata?.name || 'User'
    });
  } catch (error) {
    console.error('Signin error:', error);
    return c.json({ error: 'Failed to sign in' }, 500);
  }
});

// ==================== ITINERARY ROUTES ====================

// Generate itinerary
app.post("/make-server-04578462/api/generate-itinerary", async (c) => {
  try {
    const { destination, startDate, endDate, travelers, budget, interests, userId } = await c.req.json();
    
    // Calculate trip duration
    const start = new Date(startDate);
    const end = new Date(endDate);
    const duration = Math.ceil((end - start) / (1000 * 60 * 60 * 24));

    // Generate AI-powered itinerary (simulated)
    const itinerary = {
      id: `itinerary_${Date.now()}`,
      title: `${duration}-Day ${destination} Adventure`,
      destination,
      startDate,
      endDate,
      duration,
      travelers: parseInt(travelers),
      budget,
      interests,
      createdAt: new Date().toISOString(),
      days: generateDays(duration, destination, interests),
      recommendations: generateRecommendations(destination, interests, budget)
    };

    // Save itinerary if user is signed in
    if (userId) {
      await kv.set(`itinerary:${itinerary.id}`, itinerary);
      
      // Add to user's itineraries list
      const userItineraries = await kv.get(`user_itineraries:${userId}`) || [];
      userItineraries.push(itinerary.id);
      await kv.set(`user_itineraries:${userId}`, userItineraries);
    }

    return c.json(itinerary);
  } catch (error) {
    console.error('Error generating itinerary:', error);
    return c.json({ error: 'Failed to generate itinerary' }, 500);
  }
});

// Get user itineraries
app.get("/make-server-04578462/api/itineraries", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json([]);
    }

    const itineraryIds = await kv.get(`user_itineraries:${userId}`) || [];
    const itineraries = await kv.mget(itineraryIds.map(id => `itinerary:${id}`));
    
    return c.json(itineraries.filter(Boolean));
  } catch (error) {
    console.error('Error loading itineraries:', error);
    return c.json({ error: 'Failed to load itineraries' }, 500);
  }
});

// Save itinerary
app.post("/make-server-04578462/api/itineraries", async (c) => {
  try {
    const itinerary = await c.req.json();
    
    await kv.set(`itinerary:${itinerary.id}`, itinerary);
    
    // Add to user's itineraries list
    const userItineraries = await kv.get(`user_itineraries:${itinerary.userId}`) || [];
    if (!userItineraries.includes(itinerary.id)) {
      userItineraries.push(itinerary.id);
      await kv.set(`user_itineraries:${itinerary.userId}`, userItineraries);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error('Error saving itinerary:', error);
    return c.json({ error: 'Failed to save itinerary' }, 500);
  }
});

// ==================== MAPS ROUTES ====================

// Search location
app.get("/make-server-04578462/api/maps/search", async (c) => {
  try {
    const query = c.req.query('query');
    
    // Simulate Google Maps API response
    const mockResponse = {
      location: {
        lat: 48.8566 + (Math.random() - 0.5) * 0.1,
        lng: 2.3522 + (Math.random() - 0.5) * 0.1
      },
      name: query,
      formatted_address: `${query}, Sample Address`
    };

    return c.json(mockResponse);
  } catch (error) {
    console.error('Error searching location:', error);
    return c.json({ error: 'Failed to search location' }, 500);
  }
});

// Get nearby places
app.get("/make-server-04578462/api/maps/nearby", async (c) => {
  try {
    const lat = parseFloat(c.req.query('lat')!);
    const lng = parseFloat(c.req.query('lng')!);
    const type = c.req.query('type');

    // Generate mock nearby places
    const places = generateNearbyPlaces(lat, lng, type);
    
    return c.json({ places });
  } catch (error) {
    console.error('Error finding nearby places:', error);
    return c.json({ error: 'Failed to find nearby places' }, 500);
  }
});

// Get directions
app.post("/make-server-04578462/api/maps/directions", async (c) => {
  try {
    const { origin, destination, mode } = await c.req.json();
    
    // Mock directions response
    const directions = {
      duration: '25 mins',
      distance: '12.5 km',
      mode,
      steps: ['Head north', 'Turn right', 'Continue straight', 'Arrive at destination']
    };

    return c.json(directions);
  } catch (error) {
    console.error('Error getting directions:', error);
    return c.json({ error: 'Failed to get directions' }, 500);
  }
});

// ==================== FAVORITES ROUTES ====================

// Get user favorites
app.get("/make-server-04578462/api/favorites", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json([]);
    }

    const favorites = await kv.get(`user_favorites:${userId}`) || [];
    return c.json(favorites);
  } catch (error) {
    console.error('Error loading favorites:', error);
    return c.json({ error: 'Failed to load favorites' }, 500);
  }
});

// Add favorite
app.post("/make-server-04578462/api/favorites", async (c) => {
  try {
    const place = await c.req.json();
    const favorites = await kv.get(`user_favorites:${place.userId}`) || [];
    
    favorites.push(place);
    await kv.set(`user_favorites:${place.userId}`, favorites);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error adding favorite:', error);
    return c.json({ error: 'Failed to add favorite' }, 500);
  }
});

// Remove favorite
app.delete("/make-server-04578462/api/favorites/:placeId", async (c) => {
  try {
    const placeId = c.req.param('placeId');
    const { userId } = await c.req.json();
    
    const favorites = await kv.get(`user_favorites:${userId}`) || [];
    const updatedFavorites = favorites.filter(fav => fav.placeId !== placeId);
    
    await kv.set(`user_favorites:${userId}`, updatedFavorites);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error removing favorite:', error);
    return c.json({ error: 'Failed to remove favorite' }, 500);
  }
});

// ==================== BOOKING ROUTES ====================

// Search flights
app.post("/make-server-04578462/api/bookings/flights/search", async (c) => {
  try {
    const searchParams = await c.req.json();
    
    // Generate mock flight results
    const flights = generateFlightResults(searchParams);
    
    return c.json({ flights });
  } catch (error) {
    console.error('Error searching flights:', error);
    return c.json({ error: 'Failed to search flights' }, 500);
  }
});

// Search hotels
app.post("/make-server-04578462/api/bookings/hotels/search", async (c) => {
  try {
    const searchParams = await c.req.json();
    
    // Generate mock hotel results
    const hotels = generateHotelResults(searchParams);
    
    return c.json({ hotels });
  } catch (error) {
    console.error('Error searching hotels:', error);
    return c.json({ error: 'Failed to search hotels' }, 500);
  }
});

// Search tours
app.post("/make-server-04578462/api/bookings/tours/search", async (c) => {
  try {
    const searchParams = await c.req.json();
    
    // Generate mock tour results
    const tours = generateTourResults(searchParams);
    
    return c.json({ tours });
  } catch (error) {
    console.error('Error searching tours:', error);
    return c.json({ error: 'Failed to search tours' }, 500);
  }
});

// Create booking
app.post("/make-server-04578462/api/bookings", async (c) => {
  try {
    const booking = await c.req.json();
    booking.id = `booking_${Date.now()}`;
    
    await kv.set(`booking:${booking.id}`, booking);
    
    // Add to user's bookings list
    const userBookings = await kv.get(`user_bookings:${booking.userId}`) || [];
    userBookings.push(booking.id);
    await kv.set(`user_bookings:${booking.userId}`, userBookings);
    
    return c.json({ success: true, bookingId: booking.id });
  } catch (error) {
    console.error('Error creating booking:', error);
    return c.json({ error: 'Failed to create booking' }, 500);
  }
});

// Get user bookings
app.get("/make-server-04578462/api/bookings", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json([]);
    }

    const bookingIds = await kv.get(`user_bookings:${userId}`) || [];
    const bookings = await kv.mget(bookingIds.map(id => `booking:${id}`));
    
    return c.json(bookings.filter(Boolean));
  } catch (error) {
    console.error('Error loading bookings:', error);
    return c.json({ error: 'Failed to load bookings' }, 500);
  }
});

// ==================== HELPER FUNCTIONS ====================

function generateDays(duration, destination, interests) {
  const days = [];
  const themes = ['Arrival & Exploration', 'Cultural Discovery', 'Adventure & Activities', 'Local Experiences', 'Relaxation', 'Shopping & Cuisine', 'Departure'];
  
  for (let i = 1; i <= duration; i++) {
    const theme = themes[(i - 1) % themes.length];
    days.push({
      day: i,
      theme,
      activities: [
        { time: '9:00 AM', title: `Explore ${destination} landmarks`, location: `${destination} city center` },
        { time: '12:00 PM', title: 'Local cuisine lunch', location: 'Traditional restaurant' },
        { time: '2:00 PM', title: 'Cultural activity', location: 'Museum or gallery' },
        { time: '6:00 PM', title: 'Evening entertainment', location: 'Local venue' }
      ]
    });
  }
  
  return days;
}

function generateRecommendations(destination, interests, budget) {
  const baseRecs = ['Local food tours', 'Walking tours', 'Public transport tips'];
  const budgetRecs = {
    budget: ['Free museums', 'Street food', 'Public parks'],
    moderate: ['Guided tours', 'Restaurant dining', 'Cultural shows'],
    luxury: ['Private tours', 'Fine dining', 'Spa treatments']
  };
  
  return [...baseRecs, ...budgetRecs[budget]];
}

function generateNearbyPlaces(lat, lng, type) {
  const places = [];
  const names = {
    restaurant: ['Bistro Paris', 'Le Petit Café', 'Chez Marie', 'La Table'],
    tourist_attraction: ['Historic Monument', 'Art Gallery', 'Cathedral', 'Palace'],
    hotel: ['Grand Hotel', 'Boutique Inn', 'City Lodge', 'Palace Hotel'],
    museum: ['National Museum', 'Art Museum', 'History Center', 'Modern Gallery']
  };
  
  const placeNames = names[type] || names.tourist_attraction;
  
  for (let i = 0; i < 6; i++) {
    places.push({
      placeId: `place_${type}_${i}`,
      name: placeNames[i % placeNames.length],
      vicinity: `${Math.floor(Math.random() * 5) + 1} km from center`,
      rating: (4 + Math.random()).toFixed(1),
      userRatingsTotal: Math.floor(Math.random() * 500) + 50,
      priceLevel: Math.floor(Math.random() * 4) + 1,
      location: { lat: lat + (Math.random() - 0.5) * 0.01, lng: lng + (Math.random() - 0.5) * 0.01 },
      openingHours: { openNow: Math.random() > 0.3 }
    });
  }
  
  return places;
}

function generateFlightResults(searchParams) {
  const airlines = ['Air France', 'British Airways', 'Lufthansa', 'Delta', 'United'];
  const flights = [];
  
  for (let i = 0; i < 5; i++) {
    flights.push({
      id: `flight_${i}`,
      airline: airlines[i % airlines.length],
      route: `${searchParams.from} → ${searchParams.to}`,
      duration: `${Math.floor(Math.random() * 8) + 3}h ${Math.floor(Math.random() * 60)}m`,
      price: Math.floor(Math.random() * 800) + 200,
      originalPrice: Math.floor(Math.random() * 100) + 50,
      stops: Math.random() > 0.7 ? 1 : 0
    });
  }
  
  return flights;
}

function generateHotelResults(searchParams) {
  const hotels = [];
  const names = ['Grand Hotel', 'Boutique Inn', 'City Lodge', 'Palace Hotel', 'Modern Stay'];
  
  for (let i = 0; i < 5; i++) {
    hotels.push({
      id: `hotel_${i}`,
      name: names[i],
      description: `Comfortable stay in ${searchParams.destination}`,
      rating: (4 + Math.random()).toFixed(1),
      price: Math.floor(Math.random() * 300) + 100,
      amenities: ['WiFi', 'Breakfast', 'Pool', 'Gym', 'Spa'].slice(0, Math.floor(Math.random() * 3) + 2)
    });
  }
  
  return hotels;
}

function generateTourResults(searchParams) {
  const tours = [];
  const names = ['City Walking Tour', 'Food & Wine Experience', 'Historical Journey', 'Adventure Excursion', 'Cultural Immersion'];
  
  for (let i = 0; i < 5; i++) {
    tours.push({
      id: `tour_${i}`,
      name: names[i],
      description: `Explore ${searchParams.destination} with expert guides`,
      duration: searchParams.duration === 'half-day' ? '4 hours' : '8 hours',
      price: Math.floor(Math.random() * 150) + 50,
      rating: (4 + Math.random()).toFixed(1),
      category: searchParams.category
    });
  }
  
  return tours;
}

// ==================== USER PROFILE ROUTES ====================

// Update user profile
app.put("/make-server-04578462/api/user/profile", async (c) => {
  try {
    const profileData = await c.req.json();
    const { userId, ...updateData } = profileData;
    
    const existingUser = await kv.get(`user:${userId}`);
    if (!existingUser) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    const updatedUser = { ...existingUser, ...updateData };
    await kv.set(`user:${userId}`, updatedUser);
    
    return c.json(updatedUser);
  } catch (error) {
    console.error('Error updating profile:', error);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// ==================== NOTIFICATION ROUTES ====================

// Get user notifications
app.get("/make-server-04578462/api/notifications", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json([]);
    }

    const notifications = await kv.get(`user_notifications:${userId}`) || [];
    return c.json(notifications);
  } catch (error) {
    console.error('Error loading notifications:', error);
    return c.json({ error: 'Failed to load notifications' }, 500);
  }
});

// Mark notification as read
app.post("/make-server-04578462/api/notifications/:notificationId/read", async (c) => {
  try {
    const notificationId = c.req.param('notificationId');
    const { userId } = await c.req.json();
    
    const notifications = await kv.get(`user_notifications:${userId}`) || [];
    const updatedNotifications = notifications.map(notif =>
      notif.id === notificationId ? { ...notif, read: true } : notif
    );
    
    await kv.set(`user_notifications:${userId}`, updatedNotifications);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    return c.json({ error: 'Failed to mark notification as read' }, 500);
  }
});

// Mark all notifications as read
app.post("/make-server-04578462/api/notifications/mark-all-read", async (c) => {
  try {
    const { userId } = await c.req.json();
    
    const notifications = await kv.get(`user_notifications:${userId}`) || [];
    const updatedNotifications = notifications.map(notif => ({ ...notif, read: true }));
    
    await kv.set(`user_notifications:${userId}`, updatedNotifications);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    return c.json({ error: 'Failed to mark all notifications as read' }, 500);
  }
});

// Delete notification
app.delete("/make-server-04578462/api/notifications/:notificationId", async (c) => {
  try {
    const notificationId = c.req.param('notificationId');
    const { userId } = await c.req.json();
    
    const notifications = await kv.get(`user_notifications:${userId}`) || [];
    const updatedNotifications = notifications.filter(notif => notif.id !== notificationId);
    
    await kv.set(`user_notifications:${userId}`, updatedNotifications);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error deleting notification:', error);
    return c.json({ error: 'Failed to delete notification' }, 500);
  }
});

// Get notification settings
app.get("/make-server-04578462/api/notifications/settings", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json({});
    }

    const settings = await kv.get(`notification_settings:${userId}`) || {
      bookingUpdates: true,
      priceAlerts: true,
      itineraryReminders: true,
      promotions: false,
      weatherAlerts: true
    };
    
    return c.json(settings);
  } catch (error) {
    console.error('Error loading notification settings:', error);
    return c.json({ error: 'Failed to load notification settings' }, 500);
  }
});

// Update notification settings
app.put("/make-server-04578462/api/notifications/settings", async (c) => {
  try {
    const settings = await c.req.json();
    const { userId, ...settingsData } = settings;
    
    await kv.set(`notification_settings:${userId}`, settingsData);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error updating notification settings:', error);
    return c.json({ error: 'Failed to update notification settings' }, 500);
  }
});

// ==================== ANALYTICS ROUTES ====================

// Get user analytics
app.get("/make-server-04578462/api/analytics", async (c) => {
  try {
    const userId = c.req.query('userId');
    const timeRange = c.req.query('timeRange') || '6months';
    
    if (!userId) {
      return c.json({});
    }

    // Generate mock analytics data based on user's bookings and itineraries
    const bookings = await kv.get(`user_bookings:${userId}`) || [];
    const itineraries = await kv.get(`user_itineraries:${userId}`) || [];
    
    const analytics = generateAnalyticsData(bookings, itineraries, timeRange);
    
    return c.json(analytics);
  } catch (error) {
    console.error('Error loading analytics:', error);
    return c.json({ error: 'Failed to load analytics' }, 500);
  }
});

// ==================== PAYMENT ROUTES ====================

// Get payment methods
app.get("/make-server-04578462/api/payments/methods", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json([]);
    }

    const methods = await kv.get(`payment_methods:${userId}`) || [];
    return c.json(methods);
  } catch (error) {
    console.error('Error loading payment methods:', error);
    return c.json({ error: 'Failed to load payment methods' }, 500);
  }
});

// Add payment method
app.post("/make-server-04578462/api/payments/methods", async (c) => {
  try {
    const methodData = await c.req.json();
    const { userId, ...method } = methodData;
    
    method.id = `pm_${Date.now()}`;
    method.isDefault = false;
    
    // In production, sensitive card data would be tokenized by payment processor
    delete method.number;
    delete method.cvv;
    
    const methods = await kv.get(`payment_methods:${userId}`) || [];
    methods.push(method);
    
    await kv.set(`payment_methods:${userId}`, methods);
    
    return c.json({ success: true, id: method.id });
  } catch (error) {
    console.error('Error adding payment method:', error);
    return c.json({ error: 'Failed to add payment method' }, 500);
  }
});

// Remove payment method
app.delete("/make-server-04578462/api/payments/methods/:methodId", async (c) => {
  try {
    const methodId = c.req.param('methodId');
    const { userId } = await c.req.json();
    
    const methods = await kv.get(`payment_methods:${userId}`) || [];
    const updatedMethods = methods.filter(method => method.id !== methodId);
    
    await kv.set(`payment_methods:${userId}`, updatedMethods);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error removing payment method:', error);
    return c.json({ error: 'Failed to remove payment method' }, 500);
  }
});

// Get payment transactions
app.get("/make-server-04578462/api/payments/transactions", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json([]);
    }

    const transactions = await kv.get(`payment_transactions:${userId}`) || [];
    return c.json(transactions);
  } catch (error) {
    console.error('Error loading transactions:', error);
    return c.json({ error: 'Failed to load transactions' }, 500);
  }
});

// Google Pay status
app.get("/make-server-04578462/api/payments/google-pay/status", async (c) => {
  try {
    const userId = c.req.query('userId');
    if (!userId) {
      return c.json({ enabled: false });
    }

    const status = await kv.get(`google_pay_status:${userId}`) || { enabled: false };
    return c.json(status);
  } catch (error) {
    console.error('Error checking Google Pay status:', error);
    return c.json({ error: 'Failed to check Google Pay status' }, 500);
  }
});

// Enable Google Pay
app.post("/make-server-04578462/api/payments/google-pay/enable", async (c) => {
  try {
    const { userId } = await c.req.json();
    
    await kv.set(`google_pay_status:${userId}`, { enabled: true, enabledAt: new Date().toISOString() });
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error enabling Google Pay:', error);
    return c.json({ error: 'Failed to enable Google Pay' }, 500);
  }
});

// ==================== ADDITIONAL HELPER FUNCTIONS ====================

function generateAnalyticsData(bookings, itineraries, timeRange) {
  // Generate mock analytics based on user data
  return {
    overview: {
      totalTrips: itineraries.length,
      totalSpent: bookings.length * 450 + Math.floor(Math.random() * 2000),
      totalDays: itineraries.length * 7 + Math.floor(Math.random() * 30),
      averageTripLength: 7.4,
      favoriteDestination: 'Europe',
      savingsFromAI: Math.floor(Math.random() * 500) + 200
    },
    travelTrends: [
      { month: 'Jan', trips: Math.floor(Math.random() * 3), spending: Math.floor(Math.random() * 1000) + 500 },
      { month: 'Feb', trips: Math.floor(Math.random() * 3), spending: Math.floor(Math.random() * 1000) + 500 },
      { month: 'Mar', trips: Math.floor(Math.random() * 3), spending: Math.floor(Math.random() * 1000) + 500 },
      { month: 'Apr', trips: Math.floor(Math.random() * 3), spending: Math.floor(Math.random() * 1000) + 500 },
      { month: 'May', trips: Math.floor(Math.random() * 3), spending: Math.floor(Math.random() * 1000) + 500 },
      { month: 'Jun', trips: Math.floor(Math.random() * 3), spending: Math.floor(Math.random() * 1000) + 500 }
    ],
    destinationBreakdown: [
      { name: 'Europe', value: 45, trips: Math.floor(itineraries.length * 0.45), color: '#8884d8' },
      { name: 'Asia', value: 25, trips: Math.floor(itineraries.length * 0.25), color: '#82ca9d' },
      { name: 'North America', value: 20, trips: Math.floor(itineraries.length * 0.2), color: '#ffc658' },
      { name: 'South America', value: 10, trips: Math.floor(itineraries.length * 0.1), color: '#ff7300' }
    ],
    budgetAnalysis: {
      totalBudget: 10000,
      spent: bookings.length * 450 + Math.floor(Math.random() * 2000),
      saved: Math.floor(Math.random() * 1000) + 500,
      categories: [
        { name: 'Flights', amount: Math.floor(Math.random() * 2000) + 1000, percentage: 38 },
        { name: 'Hotels', amount: Math.floor(Math.random() * 1500) + 800, percentage: 33 },
        { name: 'Food', amount: Math.floor(Math.random() * 800) + 400, percentage: 18 },
        { name: 'Activities', amount: Math.floor(Math.random() * 600) + 300, percentage: 11 }
      ]
    },
    preferences: {
      mostBookedCategory: 'Cultural Tours',
      averageStayLength: 4.2,
      preferredBudgetRange: 'Moderate',
      bookingLeadTime: '45 days'
    }
  };
}

Deno.serve(app.fetch);